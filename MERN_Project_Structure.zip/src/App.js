import React, { Component } from 'react';
import './App.css';

class App extends Component {
  render() {
    return (
      <div>
        <p>Hello</p>        
      </div>
    );
  }
}

export default App;
