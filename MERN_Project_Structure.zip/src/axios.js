import axios from 'axios';


const instances = axios.create({
    baseURL:'baseurl'
});

export default instances;

